package net.jangaroo.jooc.backend;

/**
 * Code generation unit sink for a compilation unit.
 */
public interface CompilationUnitSink {
  void writeOutput(CodeGenerator codeGenerator);
}
