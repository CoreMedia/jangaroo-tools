joo.classLoader.prepare(














"package net.jangaroo.example",[""],




"public class HelloWorld",function($jooPublic,$jooPrivate){with(net.jangaroo.example)with($jooPublic)with($jooPrivate)return[






"public function greet",function(name){
return"Hello, "+name+"!";
},






"public function greetHtml",function(name){
return this.greet(name).replace(/&/g,"&amp;").replace(/</g,"&lt;");
},

];},[]
);