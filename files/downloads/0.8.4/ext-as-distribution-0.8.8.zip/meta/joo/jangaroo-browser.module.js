joo.loadModule("net.jangaroo","jangaroo-browser");
