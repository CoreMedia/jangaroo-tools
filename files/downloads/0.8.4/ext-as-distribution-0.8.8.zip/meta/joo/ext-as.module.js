joo.loadScript("joo/net.jangaroo.ext-as-aliases.js");
joo.loadModule("net.jangaroo", "ext-as");
