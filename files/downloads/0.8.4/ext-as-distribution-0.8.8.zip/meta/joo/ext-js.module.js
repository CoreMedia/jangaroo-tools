joo.loadScript("ext-js/adapter/ext/ext-base.js", "ext-js/adapter/ext/ext-base-debug.js");
joo.loadScript("ext-js/ext-all.js", "ext-js/ext-all-debug.js");
joo.loadDebugScript("ext-js/src/debug.js");
joo.loadScript("loadLocale.js");