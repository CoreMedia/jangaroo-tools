// simulate ActionScript's meta class "Class": at least provide placeholder and empty init function.
Class = function joo$Class(c){return c;};
Class.$class = {
  init: function(){}
};
