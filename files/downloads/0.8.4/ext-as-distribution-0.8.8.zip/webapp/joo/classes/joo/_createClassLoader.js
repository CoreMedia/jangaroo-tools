joo.classLoader = new ('localization' in joo ? joo.ResourceBundleAwareClassLoader : joo.DynamicClassLoader)();
