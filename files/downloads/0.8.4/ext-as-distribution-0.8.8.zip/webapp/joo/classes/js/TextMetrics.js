joo.classLoader.prepare("package js",/*{*/
"public interface TextMetrics",1,function($$private){;return[ /*
  function width() : Number;*/,
];},[],[], "0.8.0", "0.8.4"
);