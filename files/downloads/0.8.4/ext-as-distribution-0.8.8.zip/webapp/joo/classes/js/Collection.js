joo.classLoader.prepare("package js",/*{*/

"public class Collection extends Array",2,function($$private){;return[ 

  "public native function item"/*(index : Number) : Object;*/,

  "public native function getNamedItem"/*(name : String) : Object;*/,

];},[],["Array"], "0.8.0", "0.8.4"

);