joo.classLoader.prepare("package js",/* {*/
"public class HTMLScriptElement extends js.HTMLElement",4,function($$private){;return[ 

  "public native function get src"/*() : String;*/, // <script>, <img>

  "public native function set src"/*(url : String) : void;*/, // <script>, <img>

  "public native function get type"/*() : String;*/, // <script>, <img>

  "public native function set type"/*(url : String) : void;*/, // <script>, <img>

];},[],["js.HTMLElement"], "0.8.0", "0.8.4"
);