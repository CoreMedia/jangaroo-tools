joo.classLoader.prepare("package js",/* {*/
"public class Image extends js.HTMLImageElement",5,function($$private){;return[ 


];},[],["js.HTMLImageElement"], "0.8.0", "0.8.4"
);