joo.classLoader.prepare("package js",/*{*/

"public class Style",1,function($$private){;return[ 

  "public native function getPropertyValue"/*(propertyName : String) : String;*/,



  "public native function get cssText"/*() : String;*/,



  "public native function set cssText"/*(value : String) : void;*/,



  "public native function get azimuth"/*() : String;*/,



  "public native function set azimuth"/*(value : String) : void;*/,



  "public native function get background"/*() : String;*/,



  "public native function set background"/*(value : String) : void;*/,



  "public native function get backgroundAttachment"/*() : String;*/,



  "public native function set backgroundAttachment"/*(value : String) : void;*/,



  "public native function get backgroundColor"/*() : String;*/,



  "public native function set backgroundColor"/*(value : String) : void;*/,



  "public native function get backgroundImage"/*() : String;*/,



  "public native function set backgroundImage"/*(value : String) : void;*/,



  "public native function get backgroundPosition"/*() : String;*/,



  "public native function set backgroundPosition"/*(value : String) : void;*/,



  "public native function get backgroundRepeat"/*() : String;*/,



  "public native function set backgroundRepeat"/*(value : String) : void;*/,



  "public native function get border"/*() : String;*/,



  "public native function set border"/*(value : String) : void;*/,



  "public native function get borderCollapse"/*() : String;*/,



  "public native function set borderCollapse"/*(value : String) : void;*/,



  "public native function get borderColor"/*() : String;*/,



  "public native function set borderColor"/*(value : String) : void;*/,



  "public native function get borderSpacing"/*() : String;*/,



  "public native function set borderSpacing"/*(value : String) : void;*/,



  "public native function get borderStyle"/*() : String;*/,



  "public native function set borderStyle"/*(value : String) : void;*/,



  "public native function get borderTop"/*() : String;*/,



  "public native function set borderTop"/*(value : String) : void;*/,



  "public native function get borderRight"/*() : String;*/,



  "public native function set borderRight"/*(value : String) : void;*/,



  "public native function get borderBottom"/*() : String;*/,



  "public native function set borderBottom"/*(value : String) : void;*/,



  "public native function get borderLeft"/*() : String;*/,



  "public native function set borderLeft"/*(value : String) : void;*/,



  "public native function get borderTopColor"/*() : String;*/,



  "public native function set borderTopColor"/*(value : String) : void;*/,



  "public native function get borderRightColor"/*() : String;*/,



  "public native function set borderRightColor"/*(value : String) : void;*/,



  "public native function get borderBottomColor"/*() : String;*/,



  "public native function set borderBottomColor"/*(value : String) : void;*/,



  "public native function get borderLeftColor"/*() : String;*/,



  "public native function set borderLeftColor"/*(value : String) : void;*/,



  "public native function get borderTopStyle"/*() : String;*/,



  "public native function set borderTopStyle"/*(value : String) : void;*/,



  "public native function get borderRightStyle"/*() : String;*/,



  "public native function set borderRightStyle"/*(value : String) : void;*/,



  "public native function get borderBottomStyle"/*() : String;*/,



  "public native function set borderBottomStyle"/*(value : String) : void;*/,



  "public native function get borderLeftStyle"/*() : String;*/,



  "public native function set borderLeftStyle"/*(value : String) : void;*/,



  "public native function get borderTopWidth"/*() : String;*/,



  "public native function set borderTopWidth"/*(value : String) : void;*/,



  "public native function get borderRightWidth"/*() : String;*/,



  "public native function set borderRightWidth"/*(value : String) : void;*/,



  "public native function get borderBottomWidth"/*() : String;*/,



  "public native function set borderBottomWidth"/*(value : String) : void;*/,



  "public native function get borderLeftWidth"/*() : String;*/,



  "public native function set borderLeftWidth"/*(value : String) : void;*/,



  "public native function get borderWidth"/*() : String;*/,



  "public native function set borderWidth"/*(value : String) : void;*/,



  "public native function get bottom"/*() : String;*/,



  "public native function set bottom"/*(value : String) : void;*/,



  "public native function get captionSide"/*() : String;*/,



  "public native function set captionSide"/*(value : String) : void;*/,



  "public native function get clear"/*() : String;*/,



  "public native function set clear"/*(value : String) : void;*/,



  "public native function get clip"/*() : String;*/,



  "public native function set clip"/*(value : String) : void;*/,



  "public native function get color"/*() : String;*/,



  "public native function set color"/*(value : String) : void;*/,



  "public native function get content"/*() : String;*/,



  "public native function set content"/*(value : String) : void;*/,



  "public native function get counterIncrement"/*() : String;*/,



  "public native function set counterIncrement"/*(value : String) : void;*/,



  "public native function get counterReset"/*() : String;*/,



  "public native function set counterReset"/*(value : String) : void;*/,



  "public native function get cue"/*() : String;*/,



  "public native function set cue"/*(value : String) : void;*/,



  "public native function get cueAfter"/*() : String;*/,



  "public native function set cueAfter"/*(value : String) : void;*/,



  "public native function get cueBefore"/*() : String;*/,



  "public native function set cueBefore"/*(value : String) : void;*/,



  "public native function get cursor"/*() : String;*/,



  "public native function set cursor"/*(value : String) : void;*/,



  "public native function get direction"/*() : String;*/,



  "public native function set direction"/*(value : String) : void;*/,



  "public native function get display"/*() : String;*/,



  "public native function set display"/*(value : String) : void;*/,



  "public native function get elevation"/*() : String;*/,



  "public native function set elevation"/*(value : String) : void;*/,



  "public native function get emptyCells"/*() : String;*/,



  "public native function set emptyCells"/*(value : String) : void;*/,



  "public native function get cssFloat"/*() : String;*/,



  "public native function set cssFloat"/*(value : String) : void;*/,



  "public native function get font"/*() : String;*/,



  "public native function set font"/*(value : String) : void;*/,



  "public native function get fontFamily"/*() : String;*/,



  "public native function set fontFamily"/*(value : String) : void;*/,



  "public native function get fontSize"/*() : String;*/,



  "public native function set fontSize"/*(value : String) : void;*/,



  "public native function get fontSizeAdjust"/*() : String;*/,



  "public native function set fontSizeAdjust"/*(value : String) : void;*/,



  "public native function get fontStretch"/*() : String;*/,



  "public native function set fontStretch"/*(value : String) : void;*/,



  "public native function get fontStyle"/*() : String;*/,



  "public native function set fontStyle"/*(value : String) : void;*/,



  "public native function get fontVariant"/*() : String;*/,



  "public native function set fontVariant"/*(value : String) : void;*/,



  "public native function get fontWeight"/*() : String;*/,



  "public native function set fontWeight"/*(value : String) : void;*/,



  "public native function get height"/*() : String;*/,



  "public native function set height"/*(value : String) : void;*/,



  "public native function get left"/*() : String;*/,



  "public native function set left"/*(value : String) : void;*/,



  "public native function get letterSpacing"/*() : String;*/,



  "public native function set letterSpacing"/*(value : String) : void;*/,



  "public native function get lineHeight"/*() : String;*/,



  "public native function set lineHeight"/*(value : String) : void;*/,



  "public native function get listStyle"/*() : String;*/,



  "public native function set listStyle"/*(value : String) : void;*/,



  "public native function get listStyleImage"/*() : String;*/,



  "public native function set listStyleImage"/*(value : String) : void;*/,



  "public native function get listStylePosition"/*() : String;*/,



  "public native function set listStylePosition"/*(value : String) : void;*/,



  "public native function get listStyleType"/*() : String;*/,



  "public native function set listStyleType"/*(value : String) : void;*/,



  "public native function get margin"/*() : String;*/,



  "public native function set margin"/*(value : String) : void;*/,



  "public native function get marginTop"/*() : String;*/,



  "public native function set marginTop"/*(value : String) : void;*/,



  "public native function get marginRight"/*() : String;*/,



  "public native function set marginRight"/*(value : String) : void;*/,



  "public native function get marginBottom"/*() : String;*/,



  "public native function set marginBottom"/*(value : String) : void;*/,



  "public native function get marginLeft"/*() : String;*/,



  "public native function set marginLeft"/*(value : String) : void;*/,



  "public native function get markerOffset"/*() : String;*/,



  "public native function set markerOffset"/*(value : String) : void;*/,



  "public native function get marks"/*() : String;*/,



  "public native function set marks"/*(value : String) : void;*/,



  "public native function get maxHeight"/*() : String;*/,



  "public native function set maxHeight"/*(value : String) : void;*/,



  "public native function get maxWidth"/*() : String;*/,



  "public native function set maxWidth"/*(value : String) : void;*/,



  "public native function get minHeight"/*() : String;*/,



  "public native function set minHeight"/*(value : String) : void;*/,



  "public native function get minWidth"/*() : String;*/,



  "public native function set minWidth"/*(value : String) : void;*/,



  "public native function get orphans"/*() : String;*/,



  "public native function set orphans"/*(value : String) : void;*/,



  "public native function get outline"/*() : String;*/,



  "public native function set outline"/*(value : String) : void;*/,



  "public native function get outlineColor"/*() : String;*/,



  "public native function set outlineColor"/*(value : String) : void;*/,



  "public native function get outlineStyle"/*() : String;*/,



  "public native function set outlineStyle"/*(value : String) : void;*/,



  "public native function get outlineWidth"/*() : String;*/,



  "public native function set outlineWidth"/*(value : String) : void;*/,



  "public native function get overflow"/*() : String;*/,



  "public native function set overflow"/*(value : String) : void;*/,



  "public native function get padding"/*() : String;*/,



  "public native function set padding"/*(value : String) : void;*/,



  "public native function get paddingTop"/*() : String;*/,



  "public native function set paddingTop"/*(value : String) : void;*/,



  "public native function get paddingRight"/*() : String;*/,



  "public native function set paddingRight"/*(value : String) : void;*/,



  "public native function get paddingBottom"/*() : String;*/,



  "public native function set paddingBottom"/*(value : String) : void;*/,



  "public native function get paddingLeft"/*() : String;*/,



  "public native function set paddingLeft"/*(value : String) : void;*/,



  "public native function get page"/*() : String;*/,



  "public native function set page"/*(value : String) : void;*/,



  "public native function get pageBreakAfter"/*() : String;*/,



  "public native function set pageBreakAfter"/*(value : String) : void;*/,



  "public native function get pageBreakBefore"/*() : String;*/,



  "public native function set pageBreakBefore"/*(value : String) : void;*/,



  "public native function get pageBreakInside"/*() : String;*/,



  "public native function set pageBreakInside"/*(value : String) : void;*/,



  "public native function get pause"/*() : String;*/,



  "public native function set pause"/*(value : String) : void;*/,



  "public native function get pauseAfter"/*() : String;*/,



  "public native function set pauseAfter"/*(value : String) : void;*/,



  "public native function get pauseBefore"/*() : String;*/,



  "public native function set pauseBefore"/*(value : String) : void;*/,



  "public native function get pitch"/*() : String;*/,



  "public native function set pitch"/*(value : String) : void;*/,



  "public native function get pitchRange"/*() : String;*/,



  "public native function set pitchRange"/*(value : String) : void;*/,



  "public native function get playDuring"/*() : String;*/,



  "public native function set playDuring"/*(value : String) : void;*/,



  "public native function get position"/*() : String;*/,



  "public native function set position"/*(value : String) : void;*/,



  "public native function get quotes"/*() : String;*/,



  "public native function set quotes"/*(value : String) : void;*/,



  "public native function get richness"/*() : String;*/,



  "public native function set richness"/*(value : String) : void;*/,



  "public native function get right"/*() : String;*/,



  "public native function set right"/*(value : String) : void;*/,



  "public native function get size"/*() : String;*/,



  "public native function set size"/*(value : String) : void;*/,



  "public native function get speak"/*() : String;*/,



  "public native function set speak"/*(value : String) : void;*/,



  "public native function get speakHeader"/*() : String;*/,



  "public native function set speakHeader"/*(value : String) : void;*/,



  "public native function get speakNumeral"/*() : String;*/,



  "public native function set speakNumeral"/*(value : String) : void;*/,



  "public native function get speakPunctuation"/*() : String;*/,



  "public native function set speakPunctuation"/*(value : String) : void;*/,



  "public native function get speechRate"/*() : String;*/,



  "public native function set speechRate"/*(value : String) : void;*/,



  "public native function get stress"/*() : String;*/,



  "public native function set stress"/*(value : String) : void;*/,



  "public native function get tableLayout"/*() : String;*/,



  "public native function set tableLayout"/*(value : String) : void;*/,



  "public native function get textAlign"/*() : String;*/,



  "public native function set textAlign"/*(value : String) : void;*/,



  "public native function get textDecoration"/*() : String;*/,



  "public native function set textDecoration"/*(value : String) : void;*/,



  "public native function get textIndent"/*() : String;*/,



  "public native function set textIndent"/*(value : String) : void;*/,



  "public native function get textShadow"/*() : String;*/,



  "public native function set textShadow"/*(value : String) : void;*/,



  "public native function get textTransform"/*() : String;*/,



  "public native function set textTransform"/*(value : String) : void;*/,



  "public native function get top"/*() : String;*/,



  "public native function set top"/*(value : String) : void;*/,



  "public native function get unicodeBidi"/*() : String;*/,



  "public native function set unicodeBidi"/*(value : String) : void;*/,



  "public native function get verticalAlign"/*() : String;*/,



  "public native function set verticalAlign"/*(value : String) : void;*/,



  "public native function get visibility"/*() : String;*/,



  "public native function set visibility"/*(value : String) : void;*/,



  "public native function get voiceFamily"/*() : String;*/,



  "public native function set voiceFamily"/*(value : String) : void;*/,



  "public native function get volume"/*() : String;*/,



  "public native function set volume"/*(value : String) : void;*/,



  "public native function get whiteSpace"/*() : String;*/,



  "public native function set whiteSpace"/*(value : String) : void;*/,



  "public native function get widows"/*() : String;*/,



  "public native function set widows"/*(value : String) : void;*/,



  "public native function get width"/*() : String;*/,



  "public native function set width"/*(value : String) : void;*/,



  "public native function get wordSpacing"/*() : String;*/,



  "public native function set wordSpacing"/*(value : String) : void;*/,



  "public native function get zIndex"/*() : String;*/,



  "public native function set zIndex"/*(value : String) : void;*/,





  // CSS 3 (Firefox, Safari, Opeara):

  "public native function get opacity"/*() : String;*/,



  "public native function set opacity"/*(value : String) : void;*/,





  // IE only:

  "public native function get filter"/*() : String;*/,



  "public native function set filter"/*(value : String) : void;*/,



  // WebKit only:

  "public native function get WebkitTransform"/*() : String;*/,



  "public native function set WebkitTransform"/*(value : String) : void;*/,





];},[],[], "0.8.0", "0.8.4"

);