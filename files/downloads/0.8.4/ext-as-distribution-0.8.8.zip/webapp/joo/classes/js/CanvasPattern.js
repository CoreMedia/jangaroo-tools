joo.classLoader.prepare("package js",/*{*/
"public interface CanvasPattern",1,function($$private){;return[ 
  // opaque object
];},[],[], "0.8.0", "0.8.4"
);