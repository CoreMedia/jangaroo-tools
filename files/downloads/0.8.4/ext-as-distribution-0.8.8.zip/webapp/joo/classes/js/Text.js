joo.classLoader.prepare("package js",/*{*/
"public class Text extends js.Node",2,function($$private){;return[ 
  "public native function get data"/*() : String;*/,

  "public native function set data"/*(data : String) : void;*/,

  "public native function appendData"/*(data : String) : void;*/,
];},[],["js.Node"], "0.8.0", "0.8.4"
);