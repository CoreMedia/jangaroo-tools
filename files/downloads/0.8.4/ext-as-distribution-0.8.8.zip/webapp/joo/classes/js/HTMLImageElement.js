joo.classLoader.prepare("package js",/* {*/
"public class HTMLImageElement extends js.HTMLElement",4,function($$private){;return[ 

  "public native function get src"/*() : String;*/,

  "public native function set src"/*(url : String) : void;*/,

  "public native function get complete"/*() : Boolean;*/,

  "public native function get width"/*() : int;*/,

  "public native function set width"/*(px : int) : void;*/,

  "public native function get height"/*() : int;*/,

  "public native function set height"/*(px : int) : void;*/,

];},[],["js.HTMLElement"], "0.8.0", "0.8.4"
);