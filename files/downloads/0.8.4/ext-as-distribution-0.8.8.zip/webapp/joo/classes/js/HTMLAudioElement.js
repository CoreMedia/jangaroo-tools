joo.classLoader.prepare("package js",/* {*/
"public class HTMLAudioElement extends js.HTMLElement",4,function($$private){;return[ 

  "public native function get src"/*() : String;*/,

  "public native function set src"/*(url : String) : void;*/,

  "public native function canPlayType"/*(mimeType : String) : String;*/,

  "public native function load"/*() : void;*/,

  "public native function play"/*() : void;*/,

  "public native function pause"/*() : void;*/,

];},[],["js.HTMLElement"], "0.8.0", "0.8.4"
);