joo.classLoader.prepare("package js",/*{*/
"public interface CanvasGradient",1,function($$private){;return[ /*
  // opaque object
  function addColorStop(offset : Number, color : String) : void;*/,
];},[],[], "0.8.0", "0.8.4"
);