joo.classLoader.prepare("package js",/*{*/
"public class HTMLElement extends js.Element",3,function($$private){;return[ 
];},[],["js.Element"], "0.8.0", "0.8.4"
);