joo.classLoader.prepare("package js",/*{*/
"public class Screen",1,function($$private){;return[ 
  "public native function get top"/*() : int;*/,

  "public native function get left"/*() : int;*/,

  "public native function get width"/*() : int;*/,

  "public native function get height"/*() : int;*/,

  "public native function get pixelDepth"/*() : int;*/,

  "public native function get availTop"/*() : int;*/,

  "public native function get availLeft"/*() : int;*/,

  "public native function get availWidth"/*() : int;*/,

  "public native function get availHeight"/*() : int;*/,

  "public native function get colorDepth"/*() : int;*/,
];},[],[], "0.8.0", "0.8.4"
);