joo.classLoader.prepare("package js",/*{*/
"public interface ImageData",1,function($$private){;return[ /*

  function width() : uint;*/,/*

  function height() : uint;*/,/*

  function data() : Array;*/, // CanvasPixelArray

];},[],[], "0.8.0", "0.8.4"
);