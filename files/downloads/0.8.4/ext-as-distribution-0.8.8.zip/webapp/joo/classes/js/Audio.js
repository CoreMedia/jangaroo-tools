joo.classLoader.prepare("package js",/* {*/
"public class Audio extends js.HTMLAudioElement",5,function($$private){;return[ 


];},[],["js.HTMLAudioElement"], "0.8.0", "0.8.4"
);