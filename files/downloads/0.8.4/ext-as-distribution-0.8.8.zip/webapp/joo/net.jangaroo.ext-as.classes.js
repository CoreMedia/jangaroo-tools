// class ext.Plugin
joo.classLoader.prepare("package ext",
"public interface Plugin",1,function($$private){;return[,
];},[],[], "0.8.0", "0.8.4"
);
