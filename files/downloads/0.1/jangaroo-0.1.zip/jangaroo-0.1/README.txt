Jangaroo - Open Source developer tools for JavaScript frameworks and applications
=================================================================================

Version: 0.1 (17/07/2008 19:25:29)

Jangaroo is an Open Source project building developer tools that help creating
high-quality JavaScript frameworks and applications. Jangaroo software is released
under the Apache License, Version 2 (see LICENSE.txt).

You can find more information about Jangaroo on the project website at

   http://www.jangaroo.net/

and the Jangaroo weblog at

   http://www.jangaroo.net/blog/


Enjoy,

   The Jangaroo Team
